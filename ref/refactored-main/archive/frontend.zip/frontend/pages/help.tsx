import Head from "next/head"
import { Layout } from "@/components/layout"
import { TabsDemo, HelpAccordion } from "@/components/help-components"

export default function HelpPage() {
  return (
    <Layout>
      <Head>
        <title>Help - Northplay</title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section className="container grid items-center gap-6 pt-6 pb-8 md:py-10">
        <div className="overflow-hidden">
          <TabsDemo/>
          <HelpAccordion/>
        </div>
      </section>
    </Layout>
  )
}
