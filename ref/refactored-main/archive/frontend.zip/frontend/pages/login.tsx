import React from "react";
import Head from "next/head"
import { Layout } from "@/components/layout"
import { LoginForm } from "@/components/auth-login-form"
import { Separator } from "@/components/ui/separator"

export default function LoginPage() {
  return (
    <Layout>
      <Head>
        <title>Login Required - Northplay</title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section key="login-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
          <div>
             <div className="space-y-1">
                <h2 className="text-2xl font-semibold tracking-tight">
                  Authenticate
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  To (continue) play at Northplay, you are required to login to your account.
                </p>
              </div>
            <Separator>
              <div className="my-4" />
            </Separator>
            <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">
              <LoginForm />
            </div>
          </div>
      </section>
    </Layout>
  )
}
