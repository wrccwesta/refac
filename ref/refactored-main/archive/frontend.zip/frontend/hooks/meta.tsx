import useSWR from 'swr'
import axios from '../lib/axios'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { useToast } from "@/hooks/use-toast"

export const useMeta = ({ page } = {}) => {
    const router = useRouter()
    const { toast } = useToast()

    const { data: meta, error, mutate } = useSWR('/northplay/casino/meta', () =>
        axios
            .get('/northplay/casino/meta?page=' + page)
            .then(res => {
                res.data;
            })           
            .catch(error => {
                toast({
                  "title": "Connection Error",
                })
                console.log(error);
            }),
    )

    useEffect(() => {
        if (
            window.location.pathname === '/ffffqqwqw'
        )
            router.push('/ff')
    }, [meta, error])

    return {
        meta,
    }
}
