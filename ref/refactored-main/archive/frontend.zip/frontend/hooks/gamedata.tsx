import useSWR from 'swr'
import axios from '../lib/axios'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { useToast } from "@/hooks/use-toast"

export const useGamedata = ({ page } = {}) => {
    const router = useRouter()
    const { toast } = useToast()

    const { data: gamedata, error, mutate } = useSWR('/northplay/casino/gamedata', () =>
        axios
            .get('/northplay/casino/gamedata?page=' + page)
            .then(res => res.data)
            .catch(error => {
                toast({
                  "title": "Connection Error",
                })
            }),
    )
    const singleGameData = async ({ slugId, setGamedataStatus }) => {
        setGamedataStatus(null)
        try {
          const response = await axios.get('/northplay/casino/singlegamedata', { slug: slugId })
          .then(response => setGamedataStatus(response.data))
        } catch (error) {
            setGamedataStatus(error.response.data)
        }
    }

    useEffect(() => {
        if (
            window.location.pathname === '/ffffqqwqw'
        )
            router.push('/ff')
    }, [gamedata, error])

    return {
         gamedata,
         singleGameData,
    }
}
