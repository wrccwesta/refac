import React, { useState, useCallback, useEffect } from 'react';
import useWebSocket, { ReadyState } from 'react-use-websocket';
import { Button } from "@/components/ui/button"
import sleep from "@/lib/sleep";

interface WebsocketProps {
  auth_key: string;
}


export default function WebSocketDemo({user}) {
  const [websocketState, setWebsocketState] = useState("");
  const client = new Centrifuge(
    'wss://websocket.northplay.me/connection/websocket',
    {
        token: user?.auth_key ?? "none",
    });

    if(!user?.auth_key ) { 
      return null;
    };


    if(websocketState !== "connected") {
      client.connect();
    }

    client.on('connected', function(ctx) {
       setWebsocketState("connected");
       const sub = client.newSubscription('news');
       sub.subscribe();
        sub.on('publication', function(ctx) {
            console.log(ctx);
        });
       // React on `news` channel real-time publications.

       console.log("Conected to websocket..")
    });

    client.on('disconnect', function(ctx) {
      setWebsocketState("disconnected");
      console.log("Disconnected to websocket..")
   });
   client.on('publication', function(ctx) {
    console.log(ctx);
    });
    client.on('error', function(ctx) {
    console.log(ctx);
    });


return (
<><div>{websocketState ?? "disconnected"}</div></>
);
/*

  const [messageHistory, setMessageHistory] = useState([]);
  const { sendMessage, lastMessage, readyState } = useWebSocket(socketUrl);
  useEffect(() => {
    const fetchCommands = async () => {
        fetch('https://ws.casinoapi.northplay.me/login', { method: 'POST', credentials: 'same-origin' })
          .catch(function (err) {
            console.log(err.message);
          });
    };
    fetchCommands();
    }, []);
  useEffect(() => {
    if (lastMessage !== null) {
      setMessageHistory((prev) => prev.concat(lastMessage));
    }
  }, [lastMessage, setMessageHistory]);

  const handleClickChangeSocketUrl = useCallback(
    () => setSocketUrl('wss://casinoapi.northplay.me/ws?auth_key='+authKey),
    []
  );

  const handleClickSendMessage = useCallback(() => sendMessage('Hello'), []);

  const connectionStatus = {
    [ReadyState.CONNECTING]: 'Connecting',
    [ReadyState.OPEN]: 'Open',
    [ReadyState.CLOSING]: 'Closing',
    [ReadyState.CLOSED]: 'Closed',
    [ReadyState.UNINSTANTIATED]: 'Uninstantiated',
  }[readyState];

  return (
    <div className="flex grid">
      <div class="flex relative gap-2">
      <Button size="sm" variant="outline" onClick={handleClickChangeSocketUrl}>
        Change Socket
      </Button>
      <Button
        size="sm" variant="outline"
        onClick={handleClickSendMessage}
        disabled={readyState !== ReadyState.OPEN}
      >
        Send WS Message
      </Button>
      <Button size="sm" variant="outline">The WebSocket is currently {connectionStatus}</Button>
      {lastMessage ? <span>Last message: {lastMessage.data}</span> : null}
      <ul>
        {messageHistory.map((message, idx) => (
          <span key={idx}>{message ? message.data : null}</span>
        ))}
      </ul>
    </div>
    </div>
  );
    */

};