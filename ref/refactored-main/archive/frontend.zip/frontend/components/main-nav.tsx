import * as React from "react"
import Link from "next/link"

import { NavItem } from "@/types/nav"
import { siteConfig } from "@/config/site"
import { Icons } from "@/components/icons"
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarShortcut,
  MenubarTrigger,
} from "@/components/ui/menubar"
interface MainNavProps {
  items?: NavItem[]
}
import { useRouter } from 'next/router'
export function MainNav({ items }: MainNavProps) {
  const router = useRouter()
  const handleHomeClick = (e) => {
    e.preventDefault()
    router.push("/")
  }

  return (
    <div className="flex gap-6 md:gap-10">
      <div onClick={handleHomeClick} className="hidden cursor-pointer items-center space-x-2 md:flex">
        <Icons.logo className="h-6 w-6" />
        <span className="hidden font-bold sm:inline-block">
          {siteConfig.name}
        </span>
      </div>
      <Menubar className="hidden sm:flex rounded-none border-b border-none dark:bg-slate-900">
        <MenubarMenu>
          <Link
            href="/">
            <MenubarTrigger className="font-bold">Home</MenubarTrigger>
          </Link>
        </MenubarMenu>
        <MenubarMenu>
          <MenubarTrigger className="relative">
            Casino
          </MenubarTrigger>
          <MenubarContent>
            <MenubarItem disabled>
              Slots <MenubarShortcut>🎰</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Provably Fair <MenubarShortcut>🎲</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Live Games <MenubarShortcut>🔴</MenubarShortcut>
            </MenubarItem>
          </MenubarContent>
        </MenubarMenu>
        <MenubarMenu>
          <MenubarTrigger>Bonus</MenubarTrigger>
          <MenubarContent>
            <MenubarItem disabled>
              Deposit Bonus <MenubarShortcut>💰</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Reward Program <MenubarShortcut>👑</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Spin Drops <MenubarShortcut>💸</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Promocode <MenubarShortcut>🎫</MenubarShortcut>
            </MenubarItem>
          </MenubarContent>
        </MenubarMenu>
        <MenubarMenu>
          <MenubarTrigger>Community</MenubarTrigger>
          <MenubarContent>
            <MenubarItem disabled>
              Blog <MenubarShortcut>🎉</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Challenges <MenubarShortcut>🏋️‍♂️</MenubarShortcut>
            </MenubarItem>
            <MenubarItem disabled>
              Leaderboard <MenubarShortcut>🏆</MenubarShortcut>
            </MenubarItem>
          </MenubarContent>
        </MenubarMenu>
      </Menubar>
    </div>
  )
}
