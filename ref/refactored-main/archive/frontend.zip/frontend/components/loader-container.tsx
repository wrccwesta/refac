import React, { useState } from 'react';

export function LoaderContainer() {
  return (
          <div>
            <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">                       <div className="flex items-center justify-between">
              <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                <h3 className="mt-4 text-lg font-semibold text-slate-900 dark:text-slate-50">
                   Almost ready..
                </h3>
                <p className="mt-2 mb-4 text-sm text-slate-500 dark:text-slate-400">
                  Getting everything ready for you!
                </p>
              </div>
            </div>
            </div>
          </div>
  )
}
