import { SiteHeader } from "@/components/site-header"
import { Footer } from "@/components/footer"

interface LayoutProps {
  children: React.ReactNode
}

export function Layout({ children }: LayoutProps) {
  return (
    <>
      <SiteHeader />
      <main className="min-h-[80vh]">{children}</main>
      <Footer />
    </>
  )
}
