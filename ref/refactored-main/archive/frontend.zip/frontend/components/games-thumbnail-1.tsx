import React, { useEffect, useState } from 'react';
import Image from 'next/image'
import { Separator } from "@/components/ui/separator"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import Link from "next/link"
import { useGamedata } from '../hooks/gamedata'
import { LoaderContainer } from '@/components/loader-container'

import { cn } from "@/lib/utils"
import { AspectRatio } from "@/components/ui/aspect-ratio"
import {
  PlusCircle,
  PlayCircle,
  PinIcon,
} from "lucide-react"
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuTrigger,
} from "@/components/ui/context-menu"
interface Game {
  id: any
  slug: string
  title: string
  provider: string
}
interface GameCategory {
  popular: object
  new: object
  table_games: object
}
interface GameData {
  id: any
  slug: string
  title: string
  provider: string
}
const playlists = [
  "Supabet Room",
  "Bonus Hunt",
  "Malone Brothers",
  "Thistle Coughs",
  "Nose Repository",
  ]
import { useRouter } from 'next/router'

export function GamesThumbnailOne() {
  const router = useRouter()
  const [gamesFromStorage, setGamesFromStorage] = useState([]);
  const [gamesDataPopularFront, setGamesDataPopularFront] = useState<GameData[]>([]);
  const [gamesDataNewFront, setGamesDataNewFront] = useState<GameData[]>([]);
  const [gamesDataRewardFront, setGamesDataRewardFront] = useState<GameData[]>([]);
  const [gamesGridFront, setGamesGridFront] = useState<GameData[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [loadType, setLoadType] = useState(null);
  const [logMessage, setLogMessage] = useState("");
  const [loadTries, setLoadTries] = useState(1);
  const storageRefreshTimerSeconds = 180;

  useEffect(() => {
    if(logMessage !== "") {
      console.log(logMessage);
    }
  }, [logMessage]);


  useEffect(() => {
    try {
      localStorage.setItem("test_local_storage", "passed");
      var testOutcome = localStorage.getItem("test_local_storage");
      if(testOutcome === "passed") {
        var gamesRetrieve = localStorage.getItem("games");
        if(!gamesRetrieve) {
          setLogMessage("Local storage mode: 'set_storage'.");
          setLoadType("set_storage");
          localStorage.removeItem("test_local_storage");
        } else {
            setLogMessage("Local storage mode: 'load_storage'.");
            setLoadType("load_storage");
            localStorage.removeItem("test_local_storage");
        }
      }
    } catch(e) {
        console.error("Local storage mode: 'failed_storage'.");
        setLoadType("failed_storage");
    }
    }, []);


    const {gamedata} = useGamedata({ "page": "index" });


    useEffect(() => {
        if(!loaded) {
          var time_now = Math.floor(Date.now() / 1000);
          if(loadType === "set_storage") {
            if(gamedata?.data) {
              var gamesD = JSON.stringify(gamedata);
              localStorage.setItem("games", JSON.stringify(gamedata));
              localStorage.setItem("games_stored_at", time_now);
              setLogMessage("Games local storage set, valid for another "+storageRefreshTimerSeconds+" seconds.");
              setGamesFromStorage(JSON.parse(gamesD))
              setLoaded(true);
            }            
          }
          if(loadType === "load_storage") {
            var value = localStorage.getItem("games");
            if(!value) {
              setLogMessage("Games not found, local storage mode: 'set_storage'.");
              setLoadType("set_storage");
            } else {
              var stored_at = localStorage.getItem("games_stored_at");
              if(!stored_at) {
                setLogMessage("Stored at missing.");
                setLoadType("set_storage");
              } else {
                var storage_difference = time_now - stored_at;
                if(storage_difference > storageRefreshTimerSeconds) {
                  localStorage.removeItem("games");
                  localStorage.removeItem("games_stored_at");
                  setLoadType("set_storage");
                  setLogMessage("Refreshing games list local storage because it was set > "+storageRefreshTimerSeconds+" seconds ago.");
                } else {
                var games = !!value ? JSON.parse(value) : [];
                setLogMessage("Games loaded from local storage, valid for another "+(storageRefreshTimerSeconds - storage_difference)+" seconds.");
                setGamesFromStorage(games);
                setLoaded(true);
                }
              }
            }
          }

          if(loadType === "failed_storage") {
              if(gamedata?.data) {
                var gamesD = JSON.stringify(gamedata);
                setGamesFromStorage(JSON.parse(gamesD))
                setLoaded(true);
              }
          }
          if(!loaded) {
            setLoadTries((loadTries+1));
          }
        }
      }, [loadType, loadTries]);

      

  /*
  

  useEffect(() => {
    try {
      localStorage.setItem("test_local_storage", "passed");
      var value = localStorage.getItem("games");

      localStorage.removeItem("test_local_storage");

      if(value) {
        var games = !!value ? JSON.parse(value) : [];
        setGamesFromStorage(games)
      } else {
        if(gamedata?.data) {
          var gamesD = JSON.stringify(gamedata);
          localStorage.setItem("games", gamesD);
          setGamesFromStorage(JSON.parse(gamesD))
        }
      }

    } catch(e) {
    if(gamedata?.data) {

    var gamesD = JSON.stringify(gamedata);
    setGamesFromStorage(JSON.parse(gamesD))
    }
    }
    }, [])
    */

    useEffect(() => {
        if(gamesFromStorage.data) {
          setGamesDataNewFront(gamesFromStorage.data.new);
          setGamesDataRewardFront(gamesFromStorage.data.reward_boosted);
          setGamesGridFront(gamesFromStorage.data.game_grid);
          setGamesDataPopularFront(gamesFromStorage.data.popular);
        }
    }, [gamesFromStorage])

  if(!loaded) {
    return <LoaderContainer/>;
  }

    



  
  if(gamesFromStorage.data) {
      if(gamesFromStorage.data.popular )
              return (
                  <div className="col-span-2 overflow-hidden">
                            <div className="space-y-1">
                              <h2 className="text-2xl font-semibold tracking-tight">
                                Multiplayer Slots
                              </h2>
                              <p className="text-sm text-slate-500 dark:text-slate-400">
                                These slots you are able to link and play together using Northplay Link.
                              </p>
                            </div>
                          <Separator className="my-4" />
                          <div className="relative">
                          <ScrollArea>

                            <div className="relative flex space-x-4">
                              {gamesDataPopularFront ? 
                                    gamesDataPopularFront.map((game) => (
                                      <div key={game.id + "-row-1"} className="cursor-pointer" onClick={event => event.preventDefault() & router.push("/game/play?slug="+game.slug+"&name="+ game.title)}> 
                                        <SingleGame
                                          key={game.id + "-row-1"}
                                          game={game}
                                          imageAlt={game.id + "-row-1"}
                                          className="w-[220px]"
                                        />
                                      </div>
                                      ))
                                  :
                                  <div>...</div>
                              }
                            </div>
                            <ScrollBar className="h-2 max-w-[80vw]" orientation="horizontal" />
                            </ScrollArea>
                          </div>
                          <div className="mt-12 space-y-1">
                            <h2 className="text-2xl font-semibold tracking-tight">
                              Increased Reward Games
                            </h2>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                              Daily collection of games that earn you 50% increased reward points.
                            </p>
                          </div>
                          <Separator className="my-4" />
                          <div className="relative">
                            <ScrollArea>
                              <div className="relative flex space-x-4 mb-5">
                                {gamesDataRewardFront ? 
                                      gamesDataRewardFront.map((game) => (
                                        <div key={game.id + "-row-2"} className="cursor-pointer" onClick={event => event.preventDefault() & router.push("/game/play?slug="+game.slug+"&name="+ game.title)}> 
                                          <SingleGame
                                            key={game.id + "-row-2"}
                                            game={game}
                                            imageAlt={game.id + "-row-2"}
                                            className="w-[150px]"
                                            aspectRatio={1 / 1}
                                          />
                                        </div>
                                        ))
                                    :
                                    <div>...</div>
                                }
                              </div>
                              <ScrollBar className="h-2 max-w-[80vw]" orientation="horizontal" />
                            </ScrollArea>
                          </div>
                          <div className="mt-12 space-y-1">
                            <h2 className="text-2xl font-semibold tracking-tight">
                              New Games
                            </h2>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                              Check out these new games.
                            </p>
                          </div>
                          <Separator className="my-4" />
                          <div className="relative mb-8">
                            <ScrollArea>
                              <div className="relative flex space-x-4 mb-5">
                                {gamesDataNewFront ?
                                gamesDataNewFront.map((game) => (
                                      <div key={game.id + "-row-3"} className="cursor-pointer" onClick={event => event.preventDefault() & router.push("/game/play?slug="+game.slug+"&name="+ game.title)}> 
                                        <SingleGame
                                          key={game.id + "-row-3"}
                                          game={game}
                                          imageAlt={game.id + "-row-3"}
                                          className="w-[150px]"
                                          aspectRatio={1 / 1}
                                        /> 
                                        </div>
                                        ))
                                        :
                                        <div>Loading..</div>
                                  }
                              </div>
                              <ScrollBar className="h-2 max-w-[80vw]" orientation="horizontal" />
                            </ScrollArea>
                          </div>
                      </div>
  )
}  }

interface SingleGameProps extends React.HTMLAttributes<HTMLDivElement> {
  key: string
  game: Game
  imageAlt: string
  aspectRatio?: number
  className?: string
}

function SingleGame({
  game,
  imageAlt,
  aspectRatio = 3 / 4,
  className,
  ...props
}: SingleGameProps) {
  return (
          <div key={imageAlt} className={cn("space-y-3", className)} {...props}>
            <ContextMenu>
              <ContextMenuTrigger>
                <AspectRatio
                  ratio={aspectRatio}
                  className="overflow-hidden rounded-md"
                  >
                  <Image
                    src={"https://static.dollardave.app/thumb/s3/" + game.slug + ".png"}
                    alt={game.title}
                    fill
                    placeholder="blur"
                    blurDataURL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAQAAAAnZu5uAAAAEElEQVR42mNkqGeAAkYSmABNwQKBT1lqSwAAAABJRU5ErkJggg=="
                    sizes="auto"
                    className="object-cover transition-all hover:scale-105"
                  />
                </AspectRatio>
              </ContextMenuTrigger>
              <ContextMenuContent className="w-40">
                
                <ContextMenuItem><PlayCircle className="mr-1 h-4 w-4" /> Play</ContextMenuItem>
                <ContextMenuSub>
                  <ContextMenuSubTrigger>{game.provider}</ContextMenuSubTrigger>
                  <ContextMenuSubContent className="w-48">
                    <ContextMenuItem disabled>
                      Northplay Link
                    </ContextMenuItem>
                    <ContextMenuItem>
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Create Room
                    </ContextMenuItem>
                    <ContextMenuItem>
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Spectate Random
                    </ContextMenuItem>
                    <ContextMenuSeparator />
                    <ContextMenuItem disabled>
                      Join Rooms
                    </ContextMenuItem>
                    {playlists.map((playlist) => (
                      <ContextMenuItem key={playlist}>
                        <PlayCircle className="mr-2 h-4 w-4" />{" "}
                        {playlist}
                      </ContextMenuItem>
                    ))}
                  </ContextMenuSubContent>
                </ContextMenuSub>
                <ContextMenuItem><PlayCircle className="mr-2 h-4 w-4" /> Add to Queue</ContextMenuItem>
                <ContextMenuSeparator />
                <ContextMenuItem><PinIcon className="mr-2 h-4 w-4" /> Pin Game</ContextMenuItem>
                <ContextMenuItem>Share</ContextMenuItem>
              </ContextMenuContent>
            </ContextMenu>
            <div className="space-y-1 text-sm">
              <h3 className="font-medium leading-none">{game.title}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {game.provider}
              </p>
            </div>
          </div>
          )
}

