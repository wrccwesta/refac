import { useToast } from "@/hooks/use-toast"
import sleep from "@/lib/sleep";
import React, { useState,useEffect } from 'react';

interface AlertProps {
	input: any;
}
const Alerts = ({ input }: AlertProps) => {
	const { toast } = useToast()
	const [message, setMessage] = useState("")
	const [lastMessage, setLastMessage] = useState('')
  
	useEffect(() => {
		console.log(" input message");		console.log(input);


		if(message !== input) {
			console.log("Setting input message");
			setMessage(input);
		}
 }, [input]);
	
	useEffect(() => {
		if(message !== "") {
		console.log("alert incoming");
		console.log(message);
			toast({
				title: "Alert",
				description: message,
			});
		}
	 }, [message]);



}

export { Alerts };