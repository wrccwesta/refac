import React, { useEffect, useState } from "react";
import Image from "next/image";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { PlusCircle, PlayCircle,Dice6,ArrowDownCircle } from "lucide-react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { buttonVariants, Button } from "@/components/ui/button"

interface Game {
  id: any
  slug: string
  title: string
  provider: string
}

interface GameCategory {
  popular: object;
  new: object;
  table_games: object;
}
 
interface GameData {
  id: any
  slug: string
  title: string
  provider: string
}

const playlists = [
  "Supabet Room",
  "Bonus Hunt",
  "Malone Brothers",
  "Thistle Coughs",
  "Nose Repository",
];

const PAGE_LIMIT = 18;

export default function GamesSearch({gamesGridFront}) {
  const [gamesFromStorage, setGamesFromStorage] = useState([]);
  const [gamesData, setGamesData] = useState<GameData[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [pageCount, setPageCount] = useState(1);

  useEffect(() => {
    setGamesFromStorage(gamesGridFront);
  }, [gamesGridFront]);

const gamesFiltered = gamesGridFront.filter(game =>game.title.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, PAGE_LIMIT * pageCount);
  const noMoreGames = gamesFiltered.length <= PAGE_LIMIT * (pageCount - 1);

  const loadMore = () => setPageCount(pageCount + 1);

  return (
    <div className="overflow-hidden mx-auto">
      <div className="space-y-1">
        <h2 className="text-2xl font-semibold tracking-tight">Search</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Look up your own favorites and start playing.
        </p>
        <div className="flex h-full w-full flex-col overflow-hidden rounded-md border border-slate-300 dark:border-slate-600  bg-white dark:bg-slate-800 rounded-lg border border-slate-100 shadow-md dark:border-slate-800">
          <div className="flex items-center px-4 dark:border-b-slate-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-2 h-4 w-4 shrink-0 opacity-50"
            >
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>

            <input
              type="text"
              placeholder="Enter your search keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-slate-400 disabled:cursor-not-allowed disabled:opacity-50 dark:text-slate-50"
            />
          </div>
        </div>
      </div>
      <Separator className="my-2" />
      <section className="overflow-hidden">
          <div className="-m-1 flex flex-wrap md:-m-2">
            {gamesFiltered.length > 0 ? (
              gamesFiltered.map((game) => (
                <div className="flex w-1/2 sm:w-1/3 md:w-1/6 lg:w-1/10" key={game.id}>
                  <div className="w-full p-1 md:p-2">
                    <SingleGame
                      game={game}
                      aspectRatio={1 / 1}
                      className="rounded-lg"
                    />
                  </div>
                </div>
              ))
            ) : (
              <div>...</div>
            )}
          </div>
          <div className="mt-10 flex items-center justify-center">
          {!noMoreGames && (
            <Button
                key="load-more-button"
                onClick={loadMore}
                className={"tracking-widest font-semibold line-clamp-2 transition-all min-w-[100px] cursor-pointer disabled mr-2"}
              >
                <ArrowDownCircle className="mr-2 h-4 w-4" />
                Load more games
            </Button>
          )}
          </div>
      </section>
    </div>
  );
}

interface SingleGameProps extends React.HTMLAttributes<HTMLDivElement> {
  game: Game;
  aspectRatio?: number;
  className?: string;
}

function SingleGame({
  game,
  aspectRatio = 3 / 4,
  className,
  ...props
}: SingleGameProps) {
  return (
    <div
      key={game.id}
      className={cn("space-y-2 mb-2", className)}
      {...props}
    >
      <ContextMenu>
        <ContextMenuTrigger>
          <AspectRatio
            ratio={aspectRatio}
            className="overflow-hidden rounded-md"
          >
            <Image
              src={
                "/thumb/s3/" + game.slug + ".png"
              }
              alt={game.title}
              fill
              sizes="auto"
              className="object-cover transition-all hover:scale-105"
            />
          </AspectRatio>
        </ContextMenuTrigger>
        <ContextMenuContent className="w-40">
          <ContextMenuItem>Add to Favorites</ContextMenuItem>
          <ContextMenuSub>
            <ContextMenuSubTrigger>Play Multiplayer</ContextMenuSubTrigger>
            <ContextMenuSubContent className="w-48">
              <ContextMenuItem disabled>
                Northplay Link
              </ContextMenuItem>
              <ContextMenuItem>
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Room
              </ContextMenuItem>
              <ContextMenuItem>
                <PlusCircle className="mr-2 h-4 w-4" />
                Spectate Random
              </ContextMenuItem>
              <ContextMenuSeparator />
              <ContextMenuItem disabled>
                Join Rooms
              </ContextMenuItem>
              {playlists.map((playlist) => (
                <ContextMenuItem key={playlist}>
                  <PlayCircle className="mr-2 h-4 w-4" />{" "}
                  {playlist}
                </ContextMenuItem>
              ))}
            </ContextMenuSubContent>
          </ContextMenuSub>
          <ContextMenuSeparator />
          <ContextMenuItem>Play Next</ContextMenuItem>
          <ContextMenuItem>Play Later</ContextMenuItem>
          <ContextMenuSeparator />
          <ContextMenuItem>Like</ContextMenuItem>
          <ContextMenuItem>Share</ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>
      <div className="space-y-1 text-xs">
        <p className="font-medium leading-none">{game.name}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          {game.provider}
        </p>
      </div>
    </div>
  );
}