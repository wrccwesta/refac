import { NavItem } from "@/types/nav"

interface SiteConfig {
  name: string
  host: string
  description: string
  mainNav: NavItem[]
  links: {
    twitter: string
    github: string
    discord: string
    docs: string
  }
}
export const siteConfig: SiteConfig = {
  name: "Northplay",
  host: (process.env.NEXT_PUBLIC_ENVIRONMENT === "development" ? process.env.NEXT_PUBLIC_HOST : "n/a"),
  description:
    "The social casino venue & poker room.",
  mainNav: [
    {
      title: "Home",
      href: "/",
    },
  ],
  links: {
    twitter: "https://discordapp.com/northplay",
    discord: "https://discordapp.com/northplay",
    github: "https://github.com/northplay-bv",
    docs: "https://ui.shadcn.com",
  },
}
