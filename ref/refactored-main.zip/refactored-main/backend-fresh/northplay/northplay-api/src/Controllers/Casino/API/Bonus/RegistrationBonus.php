<?php

namespace Northplay\NorthplayApi\Controllers\Casino\API\Bonus;
use App\Http\Controllers\Controller;
use \Northplay\NorthplayApi\Controllers\Casino\API\Currency\CurrencyController;
use \Northplay\NorthplayApi\Models\UserBalanceModel;
use \Northplay\NorthplayApi\Models\UserBalanceTransactionsModel;
use App\Models\User;

class RegistrationBonus
{
	protected $all_currencies;

	public function bonusses()
	{
		


	}

	public function bonus_states($user_id) 
	{
		
	}
	

}