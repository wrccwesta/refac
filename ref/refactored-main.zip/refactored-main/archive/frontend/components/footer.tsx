import { Separator } from "@/components/ui/separator"
import { useAuth } from '@/hooks/auth'
import { siteConfig } from "@/config/site"
import { AuthDialog } from "@/components/auth-dialog"
import { useRouter } from 'next/router'

export function Footer() {
  const { user } = useAuth({ middleware: 'guest' })
  const router = useRouter()
  const handleClick = (e) => {
    e.preventDefault()
    router.push("/help")
  }
  return (
  <footer className="w-full border-t border-t-slate-200 bg-white dark:border-t-slate-700 dark:bg-slate-900">
    <div className="container md:flex h-14 items-center space-x-4 sm:justify-between sm:space-x-0 mt-4">
      <div className="space-y-1">
        <h4 className="text-sm font-medium leading-none">{siteConfig.name} -</h4>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          {siteConfig.description}
        </p>
      </div>
      <div className="hidden sm:flex mt-2 h-5 items-center space-x-2 text-sm">
            <div onClick={handleClick}>
                <HoverTooltip
                      TooltipTitle="Need Help?"
                      TooltipContent={"Find help within our F.A.Q. For urgent matters we are around the clock available by phone at +" + siteConfig.host}
                      hoverWord="Help"
                      hoverWordClass="cursor-pointer hover:underline"
                 />
            </div>
        <Separator orientation="vertical" />
        <div>Community</div>
        <Separator orientation="vertical" />
        <div>{user ? "My Account" : <AuthDialog triggerType="text" tabsDefault="register" triggerText="Register" />}</div>
        <Separator orientation="vertical" />
        <div>{user ? "Logout" : <AuthDialog triggerType="text" tabsDefault="login" triggerText="Sign In" />}</div>
      </div>
    </div>
</footer>
  )
}

import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card"

interface HoverProps {
  hoverWord: string
  hoverWordClass: string
  TooltipContent: string
  TooltipTitle: string
}

export function HoverTooltip({ ...HoverProps }: HoverProps) {
  return (
          <HoverCard>
            <HoverCardTrigger>
                <div className={HoverProps.hoverWordClass ?? "cursor-pointer"}>{HoverProps.hoverWord ?? "Undefined"}</div>
            </HoverCardTrigger>
            <HoverCardContent>
              <div className="space-y-1">
                <h4 className="text-sm font-medium">{HoverProps.TooltipTitle ?? "Undefined"}</h4>
                <p className="text-xs">
                  {HoverProps.TooltipContent ?? ""}
                </p>
              </div>
            </HoverCardContent>
          </HoverCard>
          )
}
