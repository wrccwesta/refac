"use client"

import React, { useEffect, useState } from 'react';
import { useAuth } from "@/hooks/auth"

import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function UserBalance() {
   const { user } = useAuth({ middleware: 'auth' })
   const [currentPage, setCurrentPage] = useState('apple')
   const [balances, setBalances] = useState([]);
   console.log(user);
   if(balances.length === 0 ) {
      return (
         <div>
         </div>
     )
   }

   if(user) {
      setBalances(balances => [...balances, user.balance]);
      console.log(balances);
   }

         return (
            <Select>
               <SelectTrigger className="w-[120px]">
               <SelectValue placeholder="Balance" />
               </SelectTrigger>
               <SelectContent>
               <SelectGroup>
               <SelectLabel>Fruits</SelectLabel>
                  {balances.map((Command) => (
                  <SelectItem key={Command.Sym} value={"w" + Command.sym}>Apple</SelectItem>
                  ))}
                  <SelectItem value="apple">Pineapple</SelectItem>
               </SelectGroup>
               <SelectSeparator />
               <SelectGroup>
          <SelectLabel>Fruits</SelectLabel>
          <SelectItem value="apple">Apple</SelectItem>
          <SelectItem value="banana">Banana</SelectItem>
          <SelectItem value="blueberry">Blueberry</SelectItem>
          <SelectItem value="grapes">Grapes</SelectItem>
          <SelectItem value="pineapple">Pineapple</SelectItem>
        </SelectGroup>
               <SelectGroup>
                  <SelectLabel>Vegetables</SelectLabel>
                  <SelectItem value="aubergine">Aubergine</SelectItem>
                  <SelectItem value="broccoli">Broccoli</SelectItem>
                  <SelectItem value="carrot" disabled>
                     Carrot
                  </SelectItem>
                  <SelectItem value="courgette">Courgette</SelectItem>
                  <SelectItem value="leek">Leek</SelectItem>
               </SelectGroup>
               <SelectSeparator />
               <SelectGroup>
                  <SelectLabel>Meat</SelectLabel>
                  <SelectItem value="beef">Beef</SelectItem>
                  <SelectItem value="chicken">Chicken</SelectItem>
                  <SelectItem value="lamb">Lamb</SelectItem>
                  <SelectItem value="pork">Pork</SelectItem>
               </SelectGroup>
               </SelectContent>
            </Select>
         )
}
