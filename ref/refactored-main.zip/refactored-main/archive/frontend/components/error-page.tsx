import Head from "next/head"
import { Layout } from "@/components/layout"
import {
  Bomb,
} from "lucide-react"

interface ErrorPageProps {
  title?: string
  error?: string
}

export default function ErrorPage({ title, error }: ErrorPageProps) {
  return (
    <Layout>
      <Head>
        <title>{title ?? "Undefined Error"}</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section key="loading-full-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
          <div>
            <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">                       <div className="flex items-center justify-between">
              <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                <Bomb  className="h-10 w-10 text-red-200" />
                <h3 className="mt-4 text-lg font-semibold text-slate-900 dark:text-slate-50">
                   {title ?? "Undefined Error.."}
                </h3>
                <p className="mt-2 mb-4 text-sm text-slate-500 dark:text-slate-400">
                    {error ?? "An error occured, try refreshing your page."}
                </p>
              </div>
            </div>
            </div>
          </div>
      </section>
    </Layout>
  )
}
