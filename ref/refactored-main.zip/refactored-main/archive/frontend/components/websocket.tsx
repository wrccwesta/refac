import { Centrifuge } from "centrifuge";
import React, { useState, useCallback, useEffect } from "react";
import { useWebsocketProvider } from "@/components/shared/websocket-provider";
import {Alerts} from "@/components/alerts"
import { useToast } from "@/hooks/use-toast"
import { useEventDataProvider } from "./shared/eventdata-provider";

const WebsocketComponent = ({user}) => {
	const [websocketData, setWebsocketData] = useWebsocketProvider();
  const [websocketState, setWebsocketState] = useState("");
  const [messageHistory, setMessageHistory] = useState([]);
  const [lastMessage, setLastMessage] = useState([]);
  const [alertMessage, setAlertMessage] = useState("");
  const [eventData, setEventData] = useEventDataProvider();
  const [newEventData, setNewEventData] = useState([]);
	const [lastEventData, setLastEventData] = useState([]);

  const [newAlertMessage, setNewAlertMessage] = useState("");
	const { toast } = useToast()


	useEffect(() => {
    	if (newEventData !== null) {
				if(newEventData !== lastEventData) {
				console.log(eventData);
				setLastEventData(newEventData);
      	setEventData((prev) => prev.concat(newEventData));
				}
    	}
  }, [newEventData]);


  useEffect(() => {
		if(newAlertMessage !== "") {
			if(alertMessage !== newAlertMessage) {
				setAlertMessage(newAlertMessage);
				toast({
					title: "Alert",
					description: newAlertMessage,
				});
			}
		}
  }, [newAlertMessage]);
  

  useEffect(() => {
    if(user) {
		setWebsocketState("connecting");
    const client = new Centrifuge(
      "wss://"+process.env.NEXT_PUBLIC_WEBSOCKET+"/connection/websocket",
      {
        token: user.websocket.auth.auth_key,
      }
    );
		client.connect();
		
    client.on("connected", function (ctx) {
      console.log("Connected to websocket..");
    });

    client.on("disconnected", function (ctx) {
      setWebsocketState("disconnected");
      console.log("Disconnected to websocket..");
    });

    client.on("error", function (ctx) {
      console.log(ctx);
    });
    

    client.on('publication', function(ctx) {
			if(ctx.data?.type) {
				if(ctx.data.type === "alert") {
					if(ctx.data.message !== alertMessage) {
						setNewAlertMessage(ctx.data.message);
					}
				}
				if(ctx.data.type === "balanceUpdate") {
					localStorage.setItem("balanceUpdate", ctx.data.message?.new_balance);
				}
				if(ctx.data.type === "event") {
						if(ctx.data !== newEventData) {
						setNewEventData(ctx.data);
						}
				}
			}
		});


		/*
    authChannel.on('publication', function(ctx) {
        console.log(ctx.data);
        if(ctx.data?.type) {
          if(ctx.data.type === "alert") {
            setNewAlertMessage(ctx.data.message);
          }
          if(ctx.data.type === "poker") {
            setNewPokerData(ctx.data.message);
          }
        }
      });
		
		authChannel.presenceStats().then(function(ctx) {
			console.log(ctx.numClients);
		}, function(err) {
				// presence stats call failed with error
		});
		*/
  }

  }, [user]);

};

export default WebsocketComponent;

