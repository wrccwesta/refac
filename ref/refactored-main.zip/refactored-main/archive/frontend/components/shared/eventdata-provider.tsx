'use client';

import React from 'react';

const EventDataContext = React.createContext<
  [any, React.Dispatch<React.SetStateAction<any>>] | undefined
>(undefined);

export function EventDataProvider({ children }: { children: React.ReactNode }) {
  const [EventData, setEventData] = React.useState([]);
  return (
    <EventDataContext.Provider value={[EventData, setEventData]}>
      {children}
    </EventDataContext.Provider>
  );
}

export function useEventDataProvider() {
  const context = React.useContext(EventDataContext);
  if (context === undefined) {
    throw new Error('useEventDataProvider must be used within a EventDataProvider');
  }
  return context;
}