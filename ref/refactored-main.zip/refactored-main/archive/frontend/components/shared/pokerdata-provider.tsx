'use client';

import React from 'react';

const PokerDataContext = React.createContext<
  [any, React.Dispatch<React.SetStateAction<any>>] | undefined
>(undefined);

export function PokerDataProvider({ children }: { children: React.ReactNode }) {
  const [pokerData, setPokerData] = React.useState([]);
  return (
    <PokerDataContext.Provider value={[pokerData, setPokerData]}>
      {children}
    </PokerDataContext.Provider>
  );
}

export function usePokerDataProvider() {
  const context = React.useContext(PokerDataContext);
  if (context === undefined) {
    throw new Error('usePokerDataProvider must be used within a PokerDataProvider');
  }
  return context;
}