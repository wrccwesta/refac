import { siteConfig } from "@/config/site";
import { MainNav } from "@/components/main-nav";
import { ThemeToggle } from "@/components/theme-toggle";
import { UserMenu } from "@/components/user-menu";
import { useAuth } from '../hooks/auth';
import React, { useState, useEffect } from 'react';
import { Menubar, MenubarContent, MenubarItem, MenubarMenu, MenubarShortcut, MenubarTrigger } from "@/components/ui/menubar";

export function Balances({userLoad}) {
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [balanceLoaded, setBalanceLoaded] = useState(false);
	const [check, setCheck] = useState(1);
  const [balanceUpdate, setBalanceUpdate] = useState(null);
	const [currentBalance, setCurrentBalance] = useState("0.00");

		useEffect(() => {
			const id = setInterval(() => {
				var balancegetter = localStorage.getItem("balanceUpdate") ?? 0;
				if(balancegetter) {
					if(balancegetter > 0) {
						setBalanceUpdate(balancegetter);
					}
				}
				setCheck(check + 1)
			}, 2000);
			return () => clearInterval(id);
		}, [check]);

  useEffect(() => {
      const storage = localStorage.getItem("selected_currency") ?? 'USD';
      setSelectedCurrency(storage);
      setBalanceLoaded(true);
  }, []);
	useEffect(() => {
	}, [userLoad]);
  const changeCurrency = (value) => {
    setSelectedCurrency(value);
    localStorage.setItem("selected_currency", value); 
  }

  const fiatStandard = [
    {
      symbol: "USD",
      name: "US Dollar",
      type: "Fiat",
      balance: 0,
    },
    {
      symbol: "EUR",
      name: "Euro",
      type: "Fiat",
      balance: 0,
    },
    {
      symbol: "BTC",
      name: "Bitcoin",
      type: "Crypto",
      balance: 0,
    }
  ]

	
  if(!userLoad || !userLoad.balance || userLoad.balance.length === 0) {
    return <></>;
  }

 
	useEffect(() => {
		setCurrentBalance(userLoad.balance[selectedCurrency]['nice']);
	}, [userLoad, balanceLoaded]);

 
  useEffect(() => {
		setCurrentBalance(balanceUpdate);
		localStorage.removeItem("balanceUpdate");
	}, [balanceUpdate]);

  return (
    <Menubar>
      <MenubarMenu value={selectedCurrency}>
        <MenubarTrigger>{currentBalance}<MenubarShortcut className="ml-2">{selectedCurrency}</MenubarShortcut></MenubarTrigger>
        <MenubarContent>
          {fiatStandard.map((game) => (
            <MenubarItem 
            key={game.symbol} 
            onClick={() => changeCurrency(game.symbol)} 
            value={game.symbol}>
            {userLoad.balance[game.symbol]['nice']}
              <MenubarShortcut>{game.name}</MenubarShortcut>
            </MenubarItem>
          ))}
        </MenubarContent>
      </MenubarMenu>
    </Menubar>
  )
}

export function SiteHeader() {
  const { user } = useAuth({ middleware: "guest" });

  return (
    <header className="sticky top-0 z-40 w-full border-b border-b-slate-200 bg-white dark:border-b-slate-700 dark:bg-slate-900">
      <div className="container flex h-14 items-center space-x-4 sm:justify-between sm:space-x-0">
        <MainNav items={siteConfig.mainNav} />
        
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-1">
            {user ? <Balances userLoad={user} /> : "guest"}
            <ThemeToggle />
            <UserMenu />
          </nav>
        </div>
      </div>
    </header>
  )
}
