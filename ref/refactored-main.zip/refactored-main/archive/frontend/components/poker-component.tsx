"use client"

import React, { useEffect, useState } from 'react';
import TableCanvas from "@/components/table/TableCanvas"
import { Slider } from "@/components/ui/slider"
import { buttonVariants, Button } from "@/components/ui/button"
import { usePokerDataProvider } from './shared/pokerdata-provider';
import {
   VolumeX,
   Volume2,
   MicOff,
 } from "lucide-react"

import { Input } from "@/components/ui/input"
export function PokerTableComponent() {
   const [callDisabled, setCallDisabled] = useState(false);

   const [soundState, setSoundState] = useState(false);
   const listenNowAlbums: Array[] = [
   {
    "msg_type": "game_state",
    "name": "TWPD",
    "max_players": 9,
    "small_blind": 1,
    "big_blind": 2,
    "buy_in": 200,
    "password": null,
    "button_idx": 0,
    "hand_num": 1,
    "game_suspended": false,
    "players": [
        {
            "index": 0,
            "player_name": "Bot 0",
            "money": 148,
            "is_active": true,
            "last_action": "check",
            "flop_cont": 50,
            "river_cont": 0,
            "turn_cont": 0,
            "preflop_cont": 2
        },
        {
            "index": 1,
            "player_name": "qwqwqqw",
            "money": 148,
            "is_active": true,
            "last_action": "check",
            "flop_cont": 50,
            "river_cont": 0,
            "turn_cont": 0,
            "preflop_cont": 2
        },
        null,
        null,
        null,
        null,
        null,
        null,
        null
    ],
    "street": "showdown",
    "current_bet": 0,
    "flop": "4d3sTs",
    "turn": "Jh",
    "river": "6d",
    "pots": [
        104
    ],
    "your_index": 1,
    "hole_cards": "Js5h",
    "showdown": [
        {
            "index": 1,
            "player_name": "qwqwqqw",
            "winner": false,
            "showCards": true,
            "hole_cards": "Js5h",
            "hand_result": "Pair",
            "constituent_cards": "Js-Jh",
            "kickers": "5h-6d-Ts"
        },
        {
            "index": 0,
            "player_name": "Bot 0",
            "winner": true,
            "showCards": true,
            "payout": 104,
            "hole_cards": "3c6h",
            "hand_result": "TwoPair",
            "constituent_cards": "3c-3s-6h-6d",
            "kickers": "Jh"
        },
      ]
      }
    ];
console.log(listenNowAlbums);

  return (
   <>
         <div class="h-[90vh] w-full flex flex-col justify-between">
         <div class="max-h-[500px] flex flex-1 flex-grow flex-col">
               <TableCanvas className="table-canvas" gameState={null} />
         </div>
         <div class="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-700">
            <div class="px-4 sm:px-6 md:px-10 lg:px-16">
               <div class="flex flex-col justify-between">
                  <div class="mt-2 grid grid-cols-1 lg:grid-cols-2 gap-1">
                     <div class="mt-2 grid gap-2">
                        <p className="text-sm font-normal text-slate-400 tracking-widest">Bet Amount</p>
                        <div className="flex w-full max-w-sm items-center gap-3 px-1">
                           <input className="rounded-none rounded-r-full lg:max-w-[150px]" type="number" value="0" id="betAmount" />
                           <Slider defaultValue={[0]} max={100} step={1} className="w-full text-white" />

                        </div>
                     <div class="mt-1 grid grid-cols-4 gap-2 md:gap-3 px-1">
                        <Button id="betPreset1" variant="outline" size="sm" className="font-thin rounded-xl">
                           <span className="text-xs tracking-wide">Min.</span>
                        </Button>
                        <Button id="betPreset2" variant="outline" size="sm" className="font-thin rounded-xl">
                           <span className="text-xs tracking-wide">2x</span>
                        </Button>
                        <Button id="betPreset3" variant="outline" size="sm" className="font-thin rounded-xl">
                           <span className="text-xs tracking-wide">3x</span>
                        </Button>
                        <Button id="betPreset4" variant="outline" size="sm" className="font-thin rounded-xl">
                           <span className="text-xs tracking-wide">Max.</span>
                        </Button>
                  </div>
                  </div>

                  <div class="mt-4 grid grid-cols-4 gap-1">
                        <Button id="fold" variant="outline" size="sm" className="font-semibold ">
                           <span className="text-sm tracking-wide">Fold</span>
                        </Button>
                        <Button id="check" variant="outline" size="sm" className="font-semibold ">
                           <span className="text-sm tracking-wide">Check</span>
                        </Button>
                        {callDisabled ?
                           <Button id="call" variant="outline" size="sm" className="font-semibold" 
                           >
                              <span className="text-sm tracking-wide">Call</span>
                           </Button>
                           :
                           <Button id="call" variant="outline" size="sm" className="font-semibold" 
                           disabled
                           >
                              <span className="text-sm tracking-wide">Call</span>
                           </Button>
                        }
                        <Button id="bet" variant="outline" size="sm" className="font-semibold ">
                           <span className="text-sm tracking-wide">Bet</span>
                        </Button>
                  </div>
               </div>
               <div class="flex flex-row w-full mt-8 mb-2 justify-between space-x-1">
                  <div class="grow">
                  </div>
                  <Button id="sitout" variant="outline" size="default" className="font-normal rounded-sm ">
                      <span className="tracking-wide">Sit Out</span>
                  </Button>
                  <Button id="soundControl" variant="outline" size="default" className="font-normal rounded-sm ">
                     {soundState ? <Volume2 /> : <VolumeX/>}
                  </Button>
               </div>    
               </div>
            </div>
         </div>
         </div>
         </>
  )
}

