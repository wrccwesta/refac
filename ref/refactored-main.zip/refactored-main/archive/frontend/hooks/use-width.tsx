import * as React from "react"
import { useEffect, useState } from 'react'


export const useWidth = () => {
  const [width, setWidth] = useState(0)
  useEffect(() => {
    const handleResize = () => setWidth(window.innerWidth)
      //make sure it set properly on the first load (before resizing)
      handleResize()
      window.addEventListener('resize', handleResize)
      return () => window.removeEventListener('resize', handleResize)
  }, [])
  return width
}