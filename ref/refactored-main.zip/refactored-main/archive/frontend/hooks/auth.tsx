import useSWR from 'swr'
import axios from '../lib/axios'
import { useEffect } from 'react'
import { useRouter } from 'next/router'

export const useAuth = ({ middleware, redirectIfAuthenticated } = {}) => {
  const router = useRouter()

  const { data: user, error, mutate } = useSWR('/northplay/casino/auth/user', () =>
    axios.get('/northplay/casino/auth/user').then(res => res.data),
    {
      onError: error => {
        if (error.response.status === 409) {
          router.push('/verify-email')
        }
      },
    }
  )

  const csrf = async () => {
    await axios.get('/sanctum/csrf-cookie')
  }

  const register = async ({ setErrors, ...props }) => {
    try {
      await csrf()
      setErrors([])
      await axios.post('/northplay/casino/auth/register', props)
      mutate()
    } catch (error) {
      console.log(error.response.data)
      setErrors(error.response.data)
    }
  }

  const login = async ({ setErrors, setStatus, ...props }) => {
    try {
      await csrf()
      setErrors([])
      setStatus(null)
      await axios.post('/northplay/casino/auth/login', props)
      mutate()
      window.location.pathname = '/'
    } catch (error) {
      console.log(error.response.data)
      setErrors(error.response.data)
    }
  }

  const changePassword = async ({ setChangePasswordStatus, setChangePasswordErrors, email }) => {
    setChangePasswordErrors([])
    setChangePasswordStatus(null)
    try {
      const response = await axios.post('/northplay/casino/auth/change-password', { email })
      setChangePasswordStatus(response.data.status)
    } catch (error) {
      setChangePasswordErrors(error.response.data)
    }
  }

  const forgotPassword = async ({ setErrors, setStatus, email }) => {
    try {
      await csrf()
      setErrors([])
      setStatus(null)
      const response = await axios.post('/northplay/casino/auth/forgot-password', { email })
      setStatus(response.data.status)
    } catch (error) {
      setErrors(error.response.data)
    }
  }

  const resetPassword = async ({ setNewPasswordErrors, setNewPasswordStatus, magicToken, magicEmail, newPassword, ...props }) => {
    try {
      await csrf()
      setNewPasswordErrors([])
      setNewPasswordStatus(null)
      const response = await axios.post('/northplay/casino/auth/reset-password', { token: magicToken, email: magicEmail, password: newPassword, password_confirmation: newPassword, ...props })
      setNewPasswordStatus(response.data.status)
    } catch (error) {
      if (error.response.status === 422) {
        setNewPasswordErrors(error.response.data.errors)
      } else {
        throw error
      }
    }
  }

  const updateEmailAddress = async ({ newEmail, setUpdateEmailStatus, ...props }) => {
    setUpdateEmailStatus(null)
    try {
      const response = await axios.post('/northplay/casino/auth/email/update-email', { email: newEmail, ...props })
      setUpdateEmailStatus(response.data.status)
    } catch (error) {
      console.log(error.response.data)
    }
  }
    const resendEmailVerification = ({ setVerificationStatus }) => {
        axios
            .post('/northplay/casino/auth/email/verification-notification')
            .then(response => setVerificationStatus(response.data.status))
    }

    const logout = async () => {
        if (! error) {
            await axios.post('/northplay/casino/auth/logout').then(() => mutate())
        }
        window.location.pathname = '/login'
    }

    useEffect(() => {
        if (middleware === 'guest' && redirectIfAuthenticated && user)
            router.push(redirectIfAuthenticated)
        if (
            window.location.pathname === '/verify-email' &&
            user?.email_verified_at
        )
            router.push(redirectIfAuthenticated)
        if (middleware === 'auth' && error) logout()
    }, [user, error])

    return {
        user,
        register,
        login,
        changePassword,
        forgotPassword,
        resetPassword,
        updateEmailAddress,
        resendEmailVerification,
        logout,
    }
}
