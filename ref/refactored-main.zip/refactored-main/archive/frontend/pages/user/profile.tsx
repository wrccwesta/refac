import Head from "next/head"
import { Layout } from "@/components/layout"
import { ProfileVerifyEmail } from "@/components/user-profile-components"
import { AppleMusicDemo } from "@/components/apple-music-demo"

export default function ProfilePage() {
  return (
    <Layout>
      <Head>
        <title>Profile - Northplay</title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
        <section key="login-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
          <div>
            <AppleMusicDemo/>
          </div>
      </section>
    </Layout>
  )
}
