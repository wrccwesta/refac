import Head from "next/head"
import Link from "next/link"

import { siteConfig } from "@/config/site"
import { Layout } from "@/components/layout"
import { ChangePasswordForm } from "@/components/auth-change-password-form"
import { Separator } from "@/components/ui/separator"
import { useRouter } from 'next/router'

export default function ChangePasswordPage() {
  const router = useRouter()
  const { token } = router.query

  return (
    <Layout>
      <Head>
        <title>Change Password - Northplay</title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section key="login-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
          <div>
             <div className="space-y-1">
                <h2 className="text-2xl font-semibold tracking-tight">
                  Change Password (final step)
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Change your password using the magic link in your e-mail box.
                </p>
              </div>
            <Separator className="my-4" />
            <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">
                {router.query ? <ChangePasswordForm defaultToken={token} defaultEmail={router.query.email} /> : " "}
            </div>
          </div>
      </section>
    </Layout>
  )
}
