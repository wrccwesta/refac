import Head from "next/head"
import { Layout } from "@/components/layout"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/hooks/auth"
import { useGamedata } from "@/hooks/gamedata"
import React, { useState, useEffect } from 'react';

export default function PlayGamePage({}) {
    const { user } = useAuth({middleware: 'guest'})
    const [slugId, setSlugId] = useState('game');
    const [gamedataStatus, setGamedataStatus] = useState(null)
    const [initLoad, setInitLoad] = useState(false);
    const [gameDataLoaded, setGameDataLoaded] = useState(false);

    return (
        <Layout>
        <Head>
            <title>Northplay</title>
            <meta
            name="description"
            content="Northplay Casino, come and play!"
            />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link rel="icon" href="/favicon.ico" />
        </Head>
        <section key="login-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
            <div>
                <div className="space-y-1">
                    <h2 className="text-2xl font-semibold tracking-tight">
                    Play Game
                    </h2>
                </div>
                <Separator className="my-4" />
                <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">
                    spaceholder
                </div>
            </div>
        </section>
        </Layout>
    )
    }
