import Head from "next/head";
import { Layout } from "@/components/layout";
import { GamesThumbnailOne } from '@/components/games-thumbnail-1';
import { useMeta } from '../hooks/meta';

export default function IndexPage() {
  const { meta } = useMeta({ page: 'index' });

  return (
    <Layout>
      <Head>
        <title>
          {meta ? meta.data.page ? meta.data.page.title : meta.global.page_title: "Northplay"}
        </title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section className="container p-6 md:p-12 items-center">
        <div className="flex h-170px bg-northplay-casino-header shrink-0 items-center justify-center rounded-md border border-dashed border-slate-100 dark:border-slate-700">
          <div className="mx-auto flex max-w-420px flex-col items-center justify-center text-center">
            <span className="text-lg font-semibold text-slate-100 dark:text-slate-100 leading-tight tracking-tighter sm:text-lg md:text-xl lg:text-2xl">
              Win <span className="font-extrabold">big</span> in{' '}
              <br className="hidden sm:inline" /> our full-moon event!
            </span>
            <p className="mt-2 mb-4 text-shadow font-sm text-sm text-slate-100 dark:text-slate-300">
              Eligible to all new players, simply create a new account and deposit over 10.00$.
            </p>
          </div>
        </div>
      </section>
      <section className="container grid items-center gap-6 pt-6 pb-8 md:py-10">
        <div className="overflow-hidden">
          <GamesThumbnailOne />
        </div>
        
      </section>
      <section className="container grid items-center gap-6 pt-6 pb-8 md:py-10">
        <div className="overflow-hidden">
        </div>
        
      </section>


    </Layout>
  );
}