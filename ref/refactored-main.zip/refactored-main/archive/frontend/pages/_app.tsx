import type { AppProps } from "next/app"
import { Inter } from 'next/font/google'
import { ThemeProvider } from "next-themes"
import { Toaster } from "@/components/ui/toaster"
import { useAuth } from "@/hooks/auth"
import "@/styles/globals.css"
import WebsocketComponent from '@/components/websocket';
import { WebsocketProvider } from "@/components/shared/websocket-provider";
import { EventDataProvider } from "@/components/shared/eventdata-provider";

const inter = Inter({ subsets: ['latin'] })

export default function App({ Component, pageProps }: AppProps) {
  const { user } = useAuth({ middleware: "guest" })

  return (
    <>
      <ThemeProvider attribute="class" defaultTheme="dark">
        <WebsocketProvider {...pageProps}> 
          <EventDataProvider {...pageProps}>
            <style jsx global>{`
              html {
                font-family: ${inter.style.fontFamily};
              }
            `}</style>
            <Component {...pageProps} />
            <WebsocketComponent user={user ?? ""} />
            <Toaster />
          </EventDataProvider>
        </WebsocketProvider> 
      </ThemeProvider>

  </>
  )
}
