import Head from "next/head"
import { Layout } from "@/components/layout"
import { useAuth } from '../hooks/auth'
import {
  LogOut,
} from "lucide-react"
export default function LogoutPage() {
    const { user, logout } = useAuth({
        middleware: 'auth',
    })

  if(user) {
    logout({})
  }

  return (
    <Layout>
      <Head>
        <title>Logging out..</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section key="logout-page-container" className="container grid px-2 py-4 md:py-10 md:px-6">
          <div>
            <div className="flex h-[350px] shrink-0 items-center justify-center rounded-md border border-dashed border-slate-200 dark:border-slate-700">                       <div className="flex items-center justify-between">
              <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
                <LogOut  className="h-10 w-10 text-slate-400" />
                <h3 className="mt-4 text-lg font-semibold text-slate-900 dark:text-slate-50">
                   Come back again!
                </h3>
                <p className="mt-2 mb-4 text-sm text-slate-500 dark:text-slate-400">
                    Logging your user out..
                </p>
              </div>
            </div>
            </div>
          </div>
      </section>
    </Layout>
  )
}
