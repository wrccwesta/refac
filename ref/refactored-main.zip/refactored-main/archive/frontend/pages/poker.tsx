import Head from "next/head"
import { Layout } from "@/components/layout"
import {GameComponent} from "@/components/game"
import { useAuth } from "@/hooks/auth"
import ErrorPage from '@/components/error-page'
import sleep from "@/lib/sleep"
import React, { useEffect } from 'react';

export default function GamePage({socketData}) {
  const { user } = useAuth({middleware: 'auth'})
  if(socketData){
    console.log('ewa broer');
    console.log(socketData);
  }

  if(!user) {
    return <ErrorPage 
            title="Authorization Error" 
            error="Seems it failed to set your magic key from server. Please relog or refresh page." 
            />;
  };

  return (
    <Layout>
      <Head>
        <title>Next.js</title>
        <meta
          name="description"
          content="Next.js template for building apps with Radix UI and Tailwind CSS"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <GameComponent />
    </Layout>
  )
}
