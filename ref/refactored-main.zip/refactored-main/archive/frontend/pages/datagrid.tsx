import DataGrid from 'react-data-grid';
import React, { useState, useEffect } from 'react';
import axios from '@/lib/axios';
import { Layout } from "@/components/layout"
import Head from "next/head"

const columns = [
  { key: 'id', name: 'ID' },
  { key: 'title', name: 'Title' }
];

const rows = [
  { id: 0, title: 'Example' },
  { id: 1, title: 'Demo' }
];

function App() {
  return 
}

export default function Datagrid() {
  return (
    <Layout>
      <Head>
        <title>Help - Northplay</title>
        <meta
          name="description"
          content="Northplay Casino, come and play!"
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <section className="container grid items-center gap-6 pt-6 pb-8 md:py-10">
        <div className="overflow-hidden">
				<DataGrid columns={columns} rows={rows} />

        </div>
      </section>
    </Layout>
  )
}
