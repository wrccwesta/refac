module.exports = {
  images: {
    domains: ["static.dollardave.app"],
    formats: ['image/webp'],
    contentSecurityPolicy: "default-src 'self'; script-src 'none';",
  },
  reactStrictMode: true,
  compress: true,
}
