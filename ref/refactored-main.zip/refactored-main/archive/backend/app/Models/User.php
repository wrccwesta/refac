<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
   ];

   public function all_balances()
   {
       $currency_controller = new \Northplay\NorthplayApi\Controllers\Casino\API\Currency\CurrencyController;
       $user_balance_model = new \Northplay\NorthplayApi\Models\UserBalanceModel;

      $all_currencies = $currency_controller->all_currencies();
      $balance_data = [];
      $auth = auth()->user();
      foreach($all_currencies as $currency) {
         $sym = $currency['symbol_id'];
         $user_balance = $user_balance_model->where("symbol_id", $sym)->where("user_id", $auth->id)->first();
         if(!$user_balance) {
            $user_balance_model->insert([
               "symbol_id" => $sym,
               "user_id" => $auth->id,
               "balance" => 0,
            ]);
            $user_balance = $user_balance_model->where("symbol_id", $sym)->first();
         }
         $int_value = (int) ($user_balance->balance * 100);
         $nice_value = number_format($user_balance->balance, $currency["decimals"], '.', '');
         $usd_value = number_format(($user_balance->balance * $currency['rate_usd']), $currency["decimals"], ".", "");
         $balance_data[$sym] = [
            "name" => $sym,
            "int" => $int_value,
            "usd" => $usd_value,
            "nice" => $nice_value,
            "rate" => $currency['rate_usd']
         ];
      }
      return $balance_data;
   }
   public function balance() {
       return $this->belongsToMany('\Northplay\NorthplayApi\Models\UserBalanceModel', 'user_id');
   }

}
