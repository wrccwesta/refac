<?php

namespace App\Listeners;

use App\Events\UserBalanceTransaction;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\User;

class UserBalanceTransactionListener implements ShouldQueue
{

    /**
     * Create the event listener.
     */
    public function __construct()
    {
				$this->ws_controller = new \Northplay\NorthplayApi\Controllers\Casino\WebsocketController;
    }

    /**
     * Handle the event.
     */
    public function handle(UserBalanceTransaction $event): void
    {
				$published_event = $event->tx;
				$published_event['tx_data'] = "hidden";

				$user_id = $published_event['user_id'];
				$user_channel = "#".$user_id;

				$build_broadcast = [
					  "event_id" => md5(json_encode($event)),
						"event" => "balanceTransaction",
						"private" => true,
						"event_data" => $published_event,
				];

				$data = [
						"type" => "event",
						"message" => $build_broadcast,
				];
				$this->ws_controller->sendMessage($user_channel, $data);
		}
}
