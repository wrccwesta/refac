
import React, { useState, useEffect } from "react";
import { Head } from '@inertiajs/react';
import AdminLayout from '@/Layouts/AdminLayout';

interface Data {
  id: number;
	data: any;
	type: any;
	created_at: string;
}
import {
  Card,
  Title,
  Flex,
  Table,
  TableRow,
  TableCell,
  TableHead,
  TableHeaderCell,
  TableBody,
  Badge,
  Button,
} from "@tremor/react";


const PAGE_SIZE = 15;
const PAGE_TITLE = "Logs";

interface PaginationTableProps {
	logs: any,
	auth: any,
	admin: any,
	log_count: number,
}

export default function PaginationTable({ logs, auth, admin, log_count }: PaginationTableProps) {
	const [page, setPage] = useState<number>(1);
  const [data, setData] = useState<Data[]>([]);

  useEffect(() => {
    setData(logs.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE));
  }, [page, logs]);

  const totalPages = Math.ceil(logs.length / PAGE_SIZE);
  const pageNumbers = Array.from(Array(totalPages), (_, i) => i + 1);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  return (
    <>
      <AdminLayout user={auth.user} header={<h2 className="font-bold text-xl text-gray-800 leading-tight">{PAGE_TITLE}</h2>} admin={admin}>
        <main className="p-4 md:p-8 mx-auto max-w-[1400px]">
          <Head title={PAGE_TITLE} />
          <Card>
            <Flex justifyContent="start" className="space-x-2">
              <Title>Log</Title>
              <Badge color="red">{log_count} errors</Badge>
            </Flex>
            <Table className="mt-6 text-xs">
              <TableHead>
                <TableRow>
                  <TableHeaderCell>ID</TableHeaderCell>
                  <TableHeaderCell>Type</TableHeaderCell>
                  <TableHeaderCell>Error</TableHeaderCell>
                  <TableHeaderCell className="text-right">Created</TableHeaderCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.id}</TableCell>
                    <TableCell>{item.type}</TableCell>
                    <TableCell>{item.data.message}</TableCell>
                    <TableCell className="text-right">
                      <Badge size="xs">{item.created_at}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div>
              <span>Page </span>
              <select value={page} onChange={(e) => handlePageChange(Number(e.target.value))}>
                {pageNumbers.map((pageNumber) => (
                  <option key={pageNumber} value={pageNumber}>
                    {pageNumber}
                  </option>
                ))}
              </select>
              <span> of {totalPages}</span>
            </div>
          </Card>
        </main>
      </AdminLayout>
    </>
  );
};
