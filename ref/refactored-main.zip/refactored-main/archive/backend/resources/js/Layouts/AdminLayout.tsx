import { useState, PropsWithChildren, ReactNode } from 'react';
import AdminNavBar from '@/Components/AdminNavBar';
import { User } from '@/types';

export default function AdminLayout({ user,  header, admin, children }: PropsWithChildren<{ user: User, admin: User, header?: ReactNode }>) {
    return (
			<div className="min-h-screen bg-gray-100">
            {header && (
                <header className="shadow">
                    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
											{header}
											<AdminNavBar admin={admin}/>
											</div>
                </header>
            )}
            <main>{children}</main>
        </div>
    );
}
