import { Tab, TabList } from "@tremor/react";
import { User } from '@/types/index';
import { useState, PropsWithChildren, ReactNode } from 'react';

export default function AdminNavBar({ admin }: PropsWithChildren<{ admin: User, header?: ReactNode }>) {
  return (
    <main>
      <TabList
        className="px-2 mt-6">
     		<a href="/admin/logs">
       		 <Tab href="/admin/logs" value="logs" text="Logs" />
				</a>
				<a href="/admin/games">
       		 <Tab href="/admin/games" value="games" text="Games" />
				</a>
      </TabList>
    </main>
  );
}