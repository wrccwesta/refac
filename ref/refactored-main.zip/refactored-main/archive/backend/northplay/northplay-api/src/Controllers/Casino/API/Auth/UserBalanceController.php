<?php

namespace Northplay\NorthplayApi\Controllers\Casino\API\Auth;
use App\Http\Controllers\Controller;
use \Northplay\NorthplayApi\Controllers\Casino\API\Currency\CurrencyController;
use \Northplay\NorthplayApi\Models\UserBalanceModel;
use \Northplay\NorthplayApi\Models\UserBalanceTransactionsModel;
use App\Models\User;

class UserBalanceController extends Controller
{
	protected $all_currencies;
	protected $user_balance_model;
	protected $user_external_controller;
	protected $currency_controller;
	protected $user_balance_transactions_model;
	
	public function __construct()
	{
		$this->currency_controller = new CurrencyController;
		$this->all_currencies = $this->currency_controller->all_currencies();
		$this->user_balance_model = new UserBalanceModel;
		$this->user_balance_transactions_model = new UserBalanceTransactionsModel;
	}

	public function get_balance($user_id, $sym) {
		return $this->get_user_balance($user_id, $sym);
	}
	
	public function user_balance($user_id, $sym) {
		return $this->get_user_balance($user_id, $sym);
	}
	
	
	public function get_user_balance($user_id, $sym)
	{
		$user_controller = new User;
		$user = $user_controller->where("id", $user_id)->first();
		if(!$user) {
			save_log("UserBalanceController", "User not found");
			abort(400, "User ".$user_id." not found.");
		}
		$user_balance = $this->user_balance_model->where("symbol_id", $sym)->where("user_id", $user_id)->first();
		if(!$user_balance) {
			$this->user_balance_model->insert([
				"symbol_id" => $sym,
				"user_id" => $user->id,
				"balance" => 0,
			]);
			$user_balance = $this->user_balance_model->where("symbol_id", $sym)->first();
		}
		$balance = $user_balance->balance;
		return $balance;
	}
	
	
	public function add_transaction_data($user_id, $amount, $direction, $sym, $new_balance, $user_balance, $tx_description, $tx_data)
	{
		$time_now = now_nice();
		$tx_data = [
			"user_id" => $user_id,
			"tx_amount" => (int) $amount,
			"tx_direction" => $direction,
			"tx_currency" => $sym,
			"tx_balance" => $new_balance,
			"tx_old_balance" => $user_balance,
			"tx_desc" => $tx_description,			
			"tx_data" => json_encode(array("tx_data_input" => $tx_data)),
			"created_at" => $time_now,
			"updated_at" => $time_now,
		];
		$tx = $this->user_balance_transactions_model->insert($tx_data);

		return $tx_data;
	}
	
	public function debit_user_balance($user_id, $sym, $amount, $tx_description, $tx_data = NULL)
	{
		$user_controller = new User;
		$amount = (int) $amount;
		$direction = "debit";
		
		$user = $user_controller->where("id", $user_id)->first();
		if(!$user) {
			save_log("UserBalanceController", "User does not exist. ".$user_id);
			abort(400, "User does not exist");
		}
		$user_balance = $this->get_user_balance($user_id, $sym);
		$new_balance = ($user_balance - $amount);
		
		if($new_balance < 0) {
			abort(400, "Not enough balance.");
		} else {
			$select_balance = $this->user_balance_model->where("symbol_id", $sym)->where("user_id", $user_id)->first();
			$select_balance->update([
				"balance" => $new_balance
			]);
		
			$tx = $this->add_transaction_data($user_id, (int) $amount, $direction, $sym, $new_balance, $user_balance, $tx_description, $tx_data);
			
			return $new_balance;
		}
	}
	
	public function credit_user_balance($user_id, $sym, $amount, $tx_description, $tx_data = NULL)
	{
		$user_controller = new User;
		$amount = (int) $amount;
		$direction = "credit";
		
		$user = $user_controller->where("id", $user_id)->first();
		if(!$user) {
			save_log("UserBalanceController", "User does not exist. ".$user_id);
			abort(400, "User does not exist");
		}
		$user_balance = $this->get_user_balance($user_id, $sym);
		$new_balance = ($user_balance + $amount);
		
		$tx = $this->add_transaction_data($user_id, (int) $amount, $direction, $sym, $new_balance, $user_balance, $tx_description, $tx_data);

		$select_balance = $this->user_balance_model->where("symbol_id", $sym)->where("user_id", $user_id)->first();
		$select_balance->update([
			"balance" => $new_balance
		]);
		
		return $new_balance;
	}
	
	

}