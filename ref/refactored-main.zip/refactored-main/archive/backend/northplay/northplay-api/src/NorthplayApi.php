<?php

namespace Northplay\NorthplayApi;

class NorthplayApi
{
}
