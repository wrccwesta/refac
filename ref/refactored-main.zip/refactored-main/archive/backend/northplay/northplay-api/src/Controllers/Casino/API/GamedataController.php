<?php
namespace Northplay\NorthplayApi\Controllers\Casino\API;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Northplay\NorthplayApi\Traits\ApiResponderTrait;

class GamedataController
{
    use ApiResponderTrait;
    public function __construct()
    {
        $this->config_model = new \Northplay\NorthplayApi\Models\ConfigModel;
        $this->games_model = new \Northplay\NorthplayApi\Models\SoftswissGameModel;
        $this->currency_controller = new \Northplay\NorthplayApi\Controllers\Casino\API\Currency\CurrencyController;
        $this->cache_timers = [
            "popular" => 300,
            "new" => 300,
            "reward_boosted" => 300,
            "reset_cache" => 120,
            "game_grid" > 180,
            "undefined" => 30,
        ];
        $this->reset_cache_check();
        $this->popular_metadata = $this->metadata_cache_helper("popular", 300); // TIMER CACHE
        $this->new_metadata = $this->metadata_cache_helper("new", 300);
        $this->reward_boosted_metadata = $this->metadata_cache_helper("reward_boosted", 120);
        $this->game_grid_metadata = $this->metadata_cache_helper("game_grid", 180); 

    }

    public function reset_cache_check() {
        $reset_cache = Cache::get("reset_cache_check");
        if(!$reset_cache) {
            $reset_cache = $this->config_model->get_config_value("force_cache_reset_metadata", "no", "environment");
            Cache::set("reset_cache_check", $reset_cache, now()->addSeconds($this->cache_timers['reset_cache']));
        }
        if($reset_cache === "yes") {
            $this->config_model->update_config_value("force_cache_reset_metadata", "no", "environment");
            Cache::forget("metadata_popular");
            Cache::forget("metadata_new");
            Cache::forget("metadata_reward_boosted");
            Cache::forget("metadata_game_grid");
        }
    }

    public function build_data($datakey)
    {
        $games_data = $this->games_model->all();

        if($datakey === "popular") {
            return $games_data->random(12);
        }
        if($datakey === "new") {
            return $games_data->random(12);
        }
        if($datakey === "reward_boosted") {
            return $games_data->random(12);
        }
        if($datakey === "game_grid") {
            return $games_data->random(50);
        }
    }

    public function metadata_cache_helper($datakey, $cache_seconds) {
        $cache_key = "metadata_".$datakey;
        $cached_array = Cache::get($cache_key);
        if(!$cached_array) {
            $build_data = $this->build_data($datakey);
            $data = array(
                "success" => true,
                "cached" => now_nice(),
                "data" => $build_data,
            );
            if($build_data) {
                Cache::set($cache_key, $data, $cache_seconds);
                $cached_array = Cache::get($cache_key);
            } else {
                save_log("GamedataController", "Building data for ${cache_key} seems to return a empty result.");
            }

            if(!$cached_array) {
                save_log("GamedataController", "Error trying to retrieve ${cache_key} key from cache while just tried to set.");
                return array(
                    "success" => "Error trying to retrieve ${cache_key} key from cache while just tried to set.",
                    "cached" => false,
                    "data" => $this->build_data($datakey),
                );
            }
        }
        return $cached_array;
    }

    public function grouped_page() {
        $popular = $this->popular_metadata;
        $new = $this->new_metadata;
        $reward_boosted = $this->reward_boosted_metadata;
        $game_grid = $this->game_grid_metadata;

        $main_data = [
            "popular" => $popular['data'] ?? false,
            "new" => $new['data'] ?? false,
            "reward_boosted" => $reward_boosted['data'] ?? false,
            "game_grid" => $game_grid['data'] ?? false,
        ];

        $cache_data = [
            "popular" => $popular['cached'] ?? false,
            "new" => $new['cached'] ?? false,
            "reward_boosted" => $reward_boosted['cached'] ?? false,
            "game_grid" => $game_grid['cached'] ?? false,
        ];
        return $this->responder_success($main_data, $cache_data, "GamedataController");
    }

    public function single_game(Request $request, $game) {
        $main_data['single'] = $game;
        $main_data['auth'] = ($request->user() ? $request->user() : array());
        $main_data['balances'] = ($request->user() ? $request->user()->all_balances() : array());
        $dog = new \Northplay\NorthplayApi\Controllers\DogCallbackController;
        $main_data['session'] = ($request->user() ? $dog->create_session($request->page, auth()->user()->id, 'USD') : array());
        $cache_data = false;
        return $this->responder_success($main_data, $cache_data, "GamedataController");
    }

    public function retrieve(Request $request)
    {
        if($request->page) {
            if($request->page === "game") {
                return response()->noContent();
            }
            $select_single_game = $this->games_model->all()->where('game_id', $request->page)->first();
            if($select_single_game) {
                return $this->single_game($request, $select_single_game);
            }
        }
        return $this->grouped_page();
    }
}