<?php

namespace Northplay\NorthplayApi\Controllers\Casino\API\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use \Northplay\NorthplayApi\Models\UserExternalAuthModel;
use \Northplay\NorthplayApi\Controllers\Casino\API\Auth\ExternalAuthController;
use \Northplay\NorthplayApi\Controllers\Casino\API\Currency\CurrencyController;
use \Northplay\NorthplayApi\Models\UserBalanceModel;

class UserAuthController extends Controller
{
	protected $user_external_controller;
	protected $user_balance_model;
	protected $currency_controller;
	protected $user_notifications;

	public function __construct()
	{
		$this->middleware(['web', 'auth']);
		$this->currency_controller = new CurrencyController;
		$this->user_balance_model = new UserBalanceModel;
		$this->user_notifications = new UserNotificationsController;
		$this->user_external_controller = new ExternalAuthController;
	}

	public function me(Request $request)
	{
		$user = $request->user();
		$data = $user;
		$data["balance"] = $this->balances();
		$data["notifications"] = $this->user_notifications->recent($request->user()->id);
		$data["websocket"] = $this->websocket($request);

		return response()->json($data, 200);
	}

	public function websocket(Request $request)
	{
	return $this->user_external_controller->websocket_details($request);
	}
	
	public function convert($amount, $to)
	{
			$currencies = collect($this->currency_controller->all_currencies());
			$to_rate = $currencies->where("symbol_id", $to)->first()['rate_usd'];
			$usd_amount = $amount;
			return $usd_amount * $to_rate;	
	}

	
	public function balances()
	{
		$all_currencies = $this->currency_controller->all_currencies();
		
		
		$balance_data = [];
		$auth = auth()->user();
		foreach($all_currencies as $currency) {
		$sym = $currency['symbol_id'];
		$user_balance = $this->user_balance_model->where("symbol_id", $sym)->where("user_id", $auth->id)->first();
		if(!$user_balance) {
			$this->user_balance_model->insert([
				"symbol_id" => $sym,
				"user_id" => $auth->id,
				"balance" => 0,
			]);
			$user_balance = $this->user_balance_model->where("symbol_id", $sym)->first();
		}
		$de_int = (($user_balance->balance) === 0 ? $user_balance->balance : $user_balance->balance / 100);
		$int_value = (int) ($user_balance->balance);
		$nice_value = number_format(($de_int), $currency["decimals"], '.', '');
		$usd_value = number_format(($nice_value / $currency['rate_usd']), $currency["decimals"], ".", "");
		$balance_data[$sym] = [
			"name" => $sym,
			"int" => $int_value,
			"nice" => $nice_value,
			"usd" => [
				"value" => number_format($usd_value, 2, ".", ""),
				"sym" => "USD",
				"sign" => "$",
			],
			"eur" => [
				"value" => number_format(($this->convert($usd_value, "EUR")), 2, ".", ""),
				"sym" => "EUR",
				"sign" => "€",
			],
			"cad" => [
				"value" => number_format(($this->convert($usd_value, "CAD")), 2, ".", ""),
				"sym" => "CAD",
				"sign" => "C$",
			],
			"gbp" => [
				"value" => number_format(($this->convert($usd_value, "GBP")), 2, ".", ""),
				"sym" => "GBP",
				"sign" => "£",
			],
		];
		}
		return $balance_data;
	}

}
