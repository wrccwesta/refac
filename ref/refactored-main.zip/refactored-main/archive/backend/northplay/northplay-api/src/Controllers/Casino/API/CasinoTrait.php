<?php
namespace Northplay\NorthplayApi\Controllers\Casino\API;

use Illuminate\Http\Client\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Northplay\NorthplayApi\Controllers\Casino\API\Auth\UserBalanceController;
use Northplay\NorthplayApi\Controllers\Casino\API\Auth\UserNotificationsController;

trait CasinoTrait
{

	public function add_balance($user_id, $currency, $amount, $tx_data)
	{
		$user_balance = new UserBalanceController;
		return $user_balance->credit_user_balance($user_id, $currency, $amount, $tx_data);
	}

	public function sendNotification($user_id, $title, $short_message, $last_message, $category, $action)
	{
        $notifications = new UserNotificationsController;
		$notifications->send(
			$user_id,
			$title,
			$short_message,
			$last_message,
			$category,
			$action,
		);
	}
	
	
}