#!/bin/bash


bash ./centrifugo gentoken -u 123